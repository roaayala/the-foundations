const permutations = function() {
  
};
  
// Do not edit below this line
module.exports = permutations;
