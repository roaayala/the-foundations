const factorial = function() {

};

// Do not edit below this line
module.exports = factorial;