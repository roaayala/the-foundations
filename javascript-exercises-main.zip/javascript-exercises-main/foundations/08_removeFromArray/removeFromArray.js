const removeFromArray = function() {
};

// Do not edit below this line
module.exports = removeFromArray;
