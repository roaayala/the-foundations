function addNumbers() {
  const a = 1;
  const b = 1;

  let result;

  result = "a" + "b"; // <------ EDIT THIS LINE

  return result;
}

// Do not change this
module.exports = addNumbers;
