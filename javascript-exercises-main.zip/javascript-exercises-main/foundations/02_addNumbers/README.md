# Exercise 02 - addNumbers

Troubleshoot and modify the existing function so that it returns the digit 2. Avoid "hard coding" the result and try to use variables `a` and `b` to get the correct output.

Currently, it is not returning the correct value.

## Hints

- You only need to edit the strings on line 7.
