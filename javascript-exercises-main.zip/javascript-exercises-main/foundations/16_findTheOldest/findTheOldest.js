const findTheOldest = function() {

};

// Do not edit below this line
module.exports = findTheOldest;
